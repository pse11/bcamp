package com.msa.api_config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiConfigApplication.class, args);
	}

}
